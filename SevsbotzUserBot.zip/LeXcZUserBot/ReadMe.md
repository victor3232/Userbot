step:
1. git clone https://github.com/LeXcZxMoDz9/LeXcZUserBot
- username : LeXcZxMoDz9
- pass : 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
- 1.sudo apt update && sudo apt upgrade -y
- 2.sudo apt install python3.10-venv ffmpeg -y
- 3.cd LeXcZUserBot
- 4.screen -S LeXcZUserBot
- 5.python3 -m venv LeXcZUserBot
- 6.source LeXcZUserBot/bin/activate
- 7.pip install --no-cache-dir -r requirements.txt
- 8.cp sample.env .env
- 9.nano .env
- 10.bash start
